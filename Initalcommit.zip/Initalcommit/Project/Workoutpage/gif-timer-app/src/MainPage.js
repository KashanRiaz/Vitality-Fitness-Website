import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const gifs = [
  'buttbridge.gif',
  'jumpingjacks.gif',
  'pushup.gif',
  // Add more gif filenames as needed
];

const MainPage = () => {
  const navigate = useNavigate();
  const [timer, setTimer] = useState(30);
  const [currentGifIndex, setCurrentGifIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    let countdownInterval;

    if (!isPaused) {
      countdownInterval = setInterval(() => {
        setTimer((prevTimer) => (prevTimer > 0 ? prevTimer - 1 : 0));
      }, 1000);
    }

    if (timer === 0) {
      clearInterval(countdownInterval);
      // Redirect to new.html once the timer is over
      navigate('new.html');
    }

    // Cleanup interval on component unmount
    return () => clearInterval(countdownInterval);
  }, [timer, isPaused, navigate]);

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleNextGif = () => {
    setCurrentGifIndex((prevIndex) => (prevIndex + 1) % gifs.length);
  };

  const handlePreviousGif = () => {
    setCurrentGifIndex(
      (prevIndex) => (prevIndex - 1 + gifs.length) % gifs.length
    );
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Your Gif Goes Here</h1>
      <img
        src={process.env.PUBLIC_URL + '/' + gifs[currentGifIndex]}
        alt="GIF"
        style={{ maxWidth: '100%', maxHeight: '400px' }}
        onError={(e) => console.error('Error loading GIF:', e)}
      />
      <h2>Timer: {timer} seconds</h2>
      <div>
        <button onClick={handlePause}>{isPaused ? 'Resume' : 'Pause'}</button>
        <button onClick={handleNextGif}>Next</button>
        <button onClick={handlePreviousGif}>Previous</button>
      </div>
    </div>
  );
};

export default MainPage;
