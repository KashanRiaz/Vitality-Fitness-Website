import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

function App() {
  const [selectedDate, setSelectedDate] = useState(null);

  const handleButtonClick = () => {
    setSelectedDate(new Date());
  };

  return (
    <div className="App">
      <h1>React Calendar Highlight</h1>
      <button onClick={handleButtonClick}>Highlight Today</button>
      <div>
        <Calendar
          value={selectedDate}
          tileContent={({ date, view }) =>
            view === 'month' &&
            selectedDate &&
            date.toDateString() === selectedDate.toDateString() ? (
              <div
                style={{
                  backgroundColor: 'rgba(0, 128, 0, 0.3)',
                  borderRadius: '50%',
                }}
              ></div>
            ) : null
          }
        />
      </div>
    </div>
  );
}

export default App;
